lista = [1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 8]
sin_repes = []
for elemento in lista:
    if elemento not in sin_repes:
        sin_repes.append(elemento)
print(sin_repes) 


